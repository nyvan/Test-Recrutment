<table class="table table-responsive table-bordered">
                        <thead class="table table-info">
                            <tr>
                                <th scope="col" class="text-capitalize text-center">jenjang pendidikan terakhir</th>
                                <th scope="col" class="text-capitalize text-center">nama institusi akademik</th>
                                <th scope="col" class="text-capitalize text-center">jurusan</th>
                                <th scope="col" class="text-capitalize text-center">tahun lulus</th>
                                <th scope="col" class="text-uppercase text-center ">ipk</th>
                            </tr>
                        </thead>
                        <tbody class="table-hover">
                            <tr>
                                <td><?= $biodata['jenjang']; ?></td>
                                <td><?= $biodata['institusi']; ?></td>
                                <td><?= $biodata['jurusan']; ?></td>
                                <td><?= $biodata['lulus']; ?></td>
                                <td><?= $biodata['IPK']; ?></td>
                                </tr>
                        </tbody>
                   </table>