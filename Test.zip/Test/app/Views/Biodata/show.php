<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Dashboard Template · Bootstrap v5.1</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/dashboard/">
    <link href="<?= base_url('asset/css/bootstrap.min.css') ;?>" rel="stylesheet">
    <link href="<?=base_url('asset/css/dashboard.css');?>" rel="stylesheet">
</head>

<body>

    <div class="container my-5">
        <div class="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg">
            <!--<div class="col-lg-7 p-3 p-lg-5 pt-lg-3">
                <h1 class="display-4 fw-bold lh-1">Border hero with cropped image and shadows</h1>
                <p class="lead">Quickly design and customize responsive mobile-first sites with Bootstrap, the world’s most popular front-end open source toolkit, featuring Sass variables and mixins, responsive grid system, extensive prebuilt components, and powerful JavaScript plugins.</p>
                <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-4 mb-lg-3">
                    <button type="button" class="btn btn-primary btn-lg px-4 me-md-2 fw-bold">Primary</button>
                    <button type="button" class="btn btn-outline-secondary btn-lg px-4">Default</button>
                </div>
            </div>

            <div class="col-lg-4 offset-lg-1 p-0 overflow-hidden shadow-lg">
                <img class="rounded-lg-3" src="bootstrap-docs.png" alt="" width="720">
            </div>-->

            <div class="img text-center mb-5">
                <img src="<?=base_url('asset/img/logo_edii.png');?>" alt="" class="rounded-lg-3">
            </div>
            <h1 class="text-uppercase text-decoration-underline fw-bold text-center mb-3">data peribadi pelamar</h1>
            
            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="posisi" class="form-label text-uppercase"> posisi dilamar</label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="posisi" id="posisi" class="form-control" value="<?= $biodata['posisi']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="nama" class="form-label text-uppercase"> nama</label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="nama" id="nama" class="form-control" value="<?= $biodata['nama']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="ktp" class="form-label text-uppercase"> no ktp</label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="ktp" id="ktp" class="form-control" value="<?= $biodata['ktp']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="tempat" class="form-label text-uppercase"> tempat lahir</label>
                </div>
                <div class="col-lg-8">
                </div>
            </div>
           
            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="tanggal_lahir" class="form-label text-uppercase"> tanggal lahir</label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="tanggal_lahir" id="tanggal_lahir" class="form-control" value="<?= $biodata['tanggal_lahir']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="jk" class="form-label text-uppercase"> jenis kelamin</label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="jk" id="jk" class="form-control" value="<?= $biodata['jk']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="agama" class="form-label text-uppercase">agama </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="agama" id="agama" class="form-control" value="<?= $biodata['agama']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="golongan_darah" class="form-label text-uppercase">golongan darah </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="golongan_darah" id="golongan_darah" class="form-control" value="<?= $biodata['golongan_darah']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="status" class="form-label text-uppercase">status </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="status" id="status" class="form-control" value="<?= $biodata['status']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="alamat_ktp" class="form-label text-uppercase">alamat ktp </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="alamat_ktp" id="alamat_ktp" class="form-control" value="<?= $biodata['alamat_ktp']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="alamat_tinggal" class="form-label text-uppercase">alamat tinggal </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="alamat_tinggal" id="alamat_tinggal" class="form-control" value="<?= $biodata['alamat_tinggal']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="" class="form-label text-uppercase">email </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="email" id="email" class="form-control" value="<?=$biodata['email'];?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="phone" class="form-label text-uppercase">no. telp </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="phone" id="phone" class="form-control" value="<?= $biodata['phone']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="orang_terdekat" class="form-label text-uppercase">orang terdekat yang dapat di hubungi </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="orang_terdekat" id="orang_terdekat" class="form-control" value="<?= $biodata['orang_terdekat']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="pendidikan" class="form-label text-uppercase">pendidikan terakhir </label>
                </div>
                <div class="col-lg-8">
                   <table class="table table-responsive table-bordered">
                        <thead class="table table-info">
                            <tr>
                               
                                <th scope="col" class="text-capitalize text-center">jenjang pendidikan terakhir</th>
                                <th scope="col" class="text-capitalize text-center">nama institusi akademik</th>
                                <th scope="col" class="text-capitalize text-center">jurusan</th>
                                <th scope="col" class="text-capitalize text-center">tahun lulus</th>
                                <th scope="col" class="text-uppercase text-center ">ipk</th>
                            </tr>
                        </thead>
                        <tbody class="table-hover">
                            <tr>
                                <td><?= $biodata['jenjang']; ?></td>
                                <td><?= $biodata['institusi']; ?></td>
                                <td><?= $biodata['jurusan']; ?></td>
                                <td><?= $biodata['lulus']; ?></td>
                                <td><?= $biodata['IPK']; ?></td>
                                </tr>

                            
                            
                       
                        </tbody>
                   </table>
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="pelatihan" class="form-label text-uppercase">riwayat pelatihan </label>
                </div>
                <div class="col-lg-8">
                   <table class="table table-responsive table-bordered">
                        <thead class="table table-info">
                            <tr>
                                <th scope="col" class="text-capitalize text-center">nama kursus / seminar</th>
                                <th scope="col" class="text-capitalize text-center">sertifikat (ada / tidak)</th>
                                <th scope="col" class="text-capitalize text-center">tahun</th>
                            </tr>
                        </thead>
                        <tbody class="table-hover">
                            <tr>
                                <td>S1</td>
                                <td>test</td>
                                <td>Informatika</td>
                            </tr>
                        </tbody>
                   </table>
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="pekerjaan" class="form-label text-uppercase">riwayat pekerjaan </label>
                </div>
                <div class="col-lg-8">
                   <table class="table table-responsive table-bordered">
                        <thead class="table table-info">
                            <tr>
                                <th scope="col" class="text-capitalize text-center">nama perusahaan</th>
                                <th scope="col" class="text-capitalize text-center">posisi terakir</th>
                                <th scope="col" class="text-capitalize text-center">pendapatan terakhir</th>
                                <th scope="col" class="text-capitalize text-center">tahun</th>
                                
                            </tr>
                        </thead>
                        <tbody class="table-hover">
                            <tr>
                                <td>S1</td>
                                <td>test</td>
                                <td>Informatika</td>
                                <td>2000</td>
                               
                            </tr>
                        </tbody>
                   </table>
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="skill" class="form-label text-uppercase">skill </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="skill" id="skill" class="form-control" value="<?= $biodata['skill']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="penempatan" class="form-label text-uppercase">bersedia di tempatkan di seluruh kantor perusahaan </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="penempatan" id="penempatan" class="form-control" value="<?= $biodata['penempatan']; ?>">
                </div>
            </div>

            <div class="input-group mb-3">
                <div class="col-lg-4">
                    <label for="penghasilan" class="form-label text-uppercase">Penghasilah yang diharapkan </label>
                </div>
                <div class="col-lg-8">
                    <input type="text" name="penghasilan" id="penghasilan" class="form-control" value="<?= $biodata['penghasilan']; ?>">
                </div>
            </div>
          
        </div>




    </div>

   

    <script src="<?=base_url('asset/js/bootstrap.bundle.min.js');?>"></script>


    <script src="<?=base_url('asset/js/dashboard.js');?>"></script>
</body>

</html>