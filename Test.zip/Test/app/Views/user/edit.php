<?= $this->extend('layouts/template'); ?>
<?= $this->section('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Update Data User</h3>
        </div>
        <div class="card-body">
            <?php if (!empty(session()->getFlashdata('error'))) : ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h4>Periksa Entrian Form</h4>
                    </hr />
                    <?php echo session()->getFlashdata('error'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <form method="post" action="<?= base_url('user/update/' . $user->id) ?>">
                <?= csrf_field(); ?>
 
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= $user->email; ?>">
                </div>
 
                
 
 
                <div class="form-group">
                    <label for="password">password</label>
                    <input type="password" class="form-control" id="password" name="password" value="<?= $user->password; ?>" />
                </div>
                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" class="form-control" id="role">
                        <option value="Admin" <?= ($user->role == "Admin" ? "selected" : ""); ?>>Admin</option>
                        <option value="User" <?= ($user->role == "User" ? "selected" : ""); ?>>User</option>
                    </select>
                </div>
 
                <div class="row mt-3">
                    <div class="form-group">
                        <input type="submit" value="Update" class="btn btn-info" />
                    </div>
                </div>
 
            </form>
        </div>
    </div>
</div>
<?= $this->endSection('content'); ?>