<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PekerjaanSeeder extends Seeder
{
    public function run()
    {
        $data = [
			[
				'perusahaan'          =>  'A',
				'posisi' =>  'Programer',
				'pendapatan' => '121212',
                'tahun' => '2015',
            ],

            [
                'perusahaan'          =>  'b',
				'posisi' =>  'Marketing',
				'pendapatan' => '121212',
                'tahun' => '2015',
            ],
		];

        $this->db->table('Pekerjaan')->insertBatch($data);
    
    }
}
