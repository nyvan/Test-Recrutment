<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PendidikanSeeder extends Seeder
{
    public function run()
    {
        $data = [
			[
				'jenjang'          =>  'S1',
				'institusi' =>  'Universitas',
				'jurusan' => 'Komputer',
                'lulus' => '2015',
                'IPK' => '3.90',
            ],

            [
                'jenjang'          =>  'S2',
				'institusi' =>  'Universitas',
				'jurusan' => 'Komputer',
                'lulus' => '2019',
                'IPK' => '3.70',
            ],
		];

        $this->db->table('pendidikan')->insertBatch($data);
    }
}
