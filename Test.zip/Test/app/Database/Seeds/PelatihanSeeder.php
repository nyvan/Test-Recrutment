<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PelatihanSeeder extends Seeder
{
    public function run()
    {
        $data = [
			[
				'seminar'          =>  'a',
				'sertifikat' =>  'ya',
				'tahun' => '2000',
                
            ],

            [
                'seminar'          =>  'c',
				'sertifikat' =>  'tidak',
				'tahun' => '2008',
                
            ],
		];

        $this->db->table('pelatihan')->insertBatch($data);
    
    }
}
