<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class BiodataSeeder extends Seeder
{
    public function run()
    {
        $data = [
			[
				'id_user'          =>  '1',
				'id_pendidikan' =>  '1',
				'id_pelatihan' => '1',
                'id_pekerjaan' => '1',
                'posisi' => 'Programmer',
                'nama' => 'Admin',
                'ktp' => '33140003121231',
                'tempat' => 'indonesia',
                'tanggal_lahir' => '1999-07-09',
                'jk' => 'PRIA',
                'agama' => 'ISLAM',
                'golongan_darah' => 'A',
                'status' => 'Belum',
                'alamat_ktp' => 'Indonesia',
                'alamat_tinggal' => 'Indonesia',
                'phone' => '080908',
                'orang_terdekat' => 'Admin',
                'skill' => 'Coding',
                'penempatan' => 'indonesia',
                'penghasilan' => '10000000',
            ],

            [
				'id_user'          =>  '2',
				'id_pendidikan' =>  '2',
				'id_pelatihan' => '2',
                'id_pekerjaan' => '2',
                'posisi' => 'Database Administrator',
                'nama' => 'User',
                'ktp' => '33140045121231',
                'tempat' => 'indonesia',
                'tanggal_lahir' => '1999-08-12',
                'jk' => 'PRIA',
                'agama' => 'ISLAM',
                'golongan_darah' => 'A',
                'status' => 'Belum',
                'alamat_ktp' => 'Indonesia',
                'alamat_tinggal' => 'Indonesia',
                'phone' => '08090865',
                'orang_terdekat' => 'Admin',
                'skill' => 'SQL',
                'penempatan' => 'indonesia',
                'penghasilan' => '8000000',
            ],
		];
        
		$this->db->table('biodata')->insertBatch($data);
    }
}
