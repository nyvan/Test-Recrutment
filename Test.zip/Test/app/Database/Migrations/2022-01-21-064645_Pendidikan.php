<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Pendidikan extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' =>[
                'type' => 'BIGINT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],

            'jenjang' =>[
                'type' => 'ENUM',
                'constraint' => "'SMA/SMK','D1','D2','D3','S1','S2','S3','LAIN_LAIN'",        
            ],

            'institusi' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],

            'jurusan' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,   
            ],

            'lulus' =>[
                'type' => 'VARCHAR',
                'constraint' => 5,   
            ],

            'IPK' =>[
                'type' => 'float',
                //'constraint' => 5,   
            ],


        ]);

        $this->forge->addPrimaryKey('id',TRUE);
        $this->forge->createTable('pendidikan',TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('pendidikan');
    }
}
