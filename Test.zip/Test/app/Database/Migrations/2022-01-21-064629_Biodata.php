<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Biodata extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' =>[
                'type' => 'BIGINT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],

            'id_user' =>[
                'type' => 'BIGINT',
                'constraint' => 11,
                
            ],

            'id_pendidikan' =>[
                'type' => 'BIGINT',
                'constraint' => 11,
                
            ],

            'id_pelatihan' =>[
                'type' => 'BIGINT',
                'constraint' => 11,
                
            ],

            'id_pekerjaan' =>[
                'type' => 'BIGINT',
                'constraint' => 11,
               
            ],

            'posisi' =>[
                'type' => 'VARCHAR',
                'constraint' => 100,        
            ],

            'nama' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],

            'ktp' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,   
            ],

            'tempat' =>[
                'type' => 'VARCHAR',
                'constraint' => 50,   
            ],

            'tanggal_lahir' =>[
                'type' => 'DATE',
                
            ],

            'jk' =>[
                'type' => 'ENUM',
                'constraint' => "'PRIA','WANITA'",
                'default' => 'PRIA',        
            ],

            'agama' =>[
                'type' => 'ENUM',
                'constraint' => "'ISLAM','KRISTEN','HINDU','BHUDA','KHATOLIK','KHONGHUCU','LAIN-LAIN'",
                'default' =>'ISLAM',
                //'type' => 'VARCHAR',
                //'constraint' => 255,
            ],

            'golongan_darah' =>[
                'type' => 'ENUM',
                'constraint' => "'A','B','O','AB'",   
            ],

            'status' =>[
                'type' => 'VARCHAR',
                'constraint' => 50,   
            ],

            'alamat_ktp' =>[
                'type' => 'TEXT',
                
            ],

            'alamat_tinggal' =>[
                'type' => 'TEXT',
                        
            ],

            'phone' =>[
                'type' => 'BIGINT',
                'constraint' => 50,
            ],

            'orang_terdekat' =>[
                'type' => 'VARCHAR',
                'constraint' => 100,   
            ],

            'skill' =>[
                'type' => 'VARCHAR',
                'constraint' => 100,   
            ],

            'penempatan' =>[
                'type' => 'VARCHAR',
                'constraint' => 100,   
            ],

            'penghasilan' =>[
                'type' => 'BIGINT',
                'constraint' => 25,   
            ],


        ]);

        $this->forge->addPrimaryKey('id',TRUE);
        $this->forge->addForeignKey('id_user','user', 'id');
        $this->forge->addForeignKey('id_pendidikan','pendidikan','id');
        $this->forge->addForeignKey('id_pelatihan','pelatihan','id');
        $this->forge->addForeignKey('id_pekerjaan','pekerjaan','id');
        $this->forge->createTable('biodata');
    }

    public function down()
    {
        $this->forge->dropTable('biodata');
    }
}

