<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Pelatihan extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' =>[
                'type' => 'BIGINT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],

            'seminar' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,
                     
            ],

            'sertifikat' =>[
                'type' => 'ENUM',
                'constraint' => "'YA','TIDAK'",
            ],

            'tahun' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,   
            ],


        ]);

        $this->forge->addPrimaryKey('id',TRUE);
        $this->forge->createTable('pelatihan',TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('pelatihan');
    }
}

