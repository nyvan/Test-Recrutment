<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Pekerjaan extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' =>[
                'type' => 'BIGINT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],

            'perusahaan' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,        
            ],

            'posisi' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],

            'pendapatan' =>[
                'type' => 'BIGINT',
                'constraint' => 25,   
            ],

            'tahun' =>[
                'type' => 'VARCHAR',
                'constraint' => 255,   
            ],

           

        ]);

        $this->forge->addPrimaryKey('id',TRUE);
        $this->forge->createTable('pekerjaan',TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('pekerjaan');
    }
}
