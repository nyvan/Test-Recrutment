<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class PekerjaanController extends BaseController
{
    public function index()
    {
        //
    }
}
