<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Biodata;
use App\Models\User;
use App\Models\Pekerjaan;
use App\Models\Pendidikan;
use App\Models\Pelatihan;

class BiodataController extends BaseController
{
    protected $biodata;

    function __construct(){
        $this->biodata = new Biodata();
        $this->user = new User();
        $this->Pekerjaan = new Pekerjaan();
        $this->Pendidikan = new Pendidikan();
        $this->Pelatihan = new Pelatihan();
        
    }
    public function index()
    {
        $data['biodata'] = $this->biodata->findAll();
       
        return view('biodata/index', $data);
    }

    public function show($id){

       /* $getDataAll = new Biodata();
        $data['biodata'] = $getDataAll->getDataAll($id);*/

        /*if ($id == false){
             $data['biodata'] = $this->biodata->getDataAll($id);
        }else{
             $data['biodata'] = $this->biodata->getWhere(['id' => $id]);
        }*/
        //$data['biodata'] = $this->biodata->getBiodata($id);
        $data['biodata'] = $this->biodata->getPendidikan($id);
        echo view('biodata/show', $data);

        //$data['biodata'] = $this->biodata->find($id);
       // return view('biodata/show', $data);
    }

    public function create()
    {
        return view('biodata/create');
    }
 
    public function store()
    {
        if (!$this->validate([
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                    
                ]
            ],
            'tempat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'tanggal_lahir' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],

            'posisi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
 
        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        }
 
        $this->biodata->insert([
            'nama' => $this->request->getVar('nama'),
            'tempat' => $this->request->getVar('tempat'),
            'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
            'posisi' => $this->request->getVar('posisi'),
           
        ]);
        session()->setFlashdata('message', 'Tambah Data biodata Berhasil');
        return redirect()->to('/biodata');
    }
 
    function edit($id)
    {
        $user = $this->user->findAll();
        $data['user'] = $user;
        $databiodata = $this->biodata->find($id);
        if (empty($databiodata)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data biodata Tidak ditemukan !');
        }
        $data['biodata'] = $databiodata;
        return view('biodata/edit', $data);
    }
 
    public function update($id)
    {
        if (!$this->validate([
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                    
                ]
            ],
            'tempat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'tanggal_lahir' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],

            'posisi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
 
        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back();
        }
 
        $this->biodata->update($id, [
            'nama' => $this->request->getVar('nama'),
            'tempat' => $this->request->getVar('tempat'),
            'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
            'posisi' => $this->request->getVar('posisi'),
            
        ]);
        session()->setFlashdata('message', 'Update Data biodata Berhasil');
        return redirect()->to('/biodata');
    }
 
    function delete($id)
    {
        $databiodata = $this->biodata->find($id);
        if (empty($databiodata)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data biodata Tidak ditemukan !');
        }
        $this->biodata->delete($id);
        session()->setFlashdata('message', 'Delete Data biodata Berhasil');
        return redirect()->to('/biodata');
    }
}
