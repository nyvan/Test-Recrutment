<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class PelatihanController extends BaseController
{
    public function index()
    {
        //
    }
}
