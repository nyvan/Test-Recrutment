<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class PendidikanController extends BaseController
{
    public function index()
    {
        //
    }
}
