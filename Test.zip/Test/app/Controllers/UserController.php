<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\Model;
use App\Models\User;

class UserController extends BaseController
{
    protected $user;
 
    function __construct()
    {
        $this->user = new User();
    }
 
    public function index()
    {
        $data['user'] = $this->user->findAll();
        return view('user/index', $data);
    }
 
    public function create()
    {
        return view('user/create');
    }
 
    public function store()
    {
        if (!$this->validate([
            'email' => [
                'rules' => 'required|valid_email',
                'errors' => [
                    'required' => '{field} Harus diisi',
                    'valid_email' => 'Email Harus Valid'
                ]
            ],
            'password' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'role' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
 
        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        }
 
        $this->user->insert([
            'email' => $this->request->getVar('email'),
            'password' => $this->request->getVar('password'),
            'role' => $this->request->getVar('role'),
           
        ]);
        session()->setFlashdata('message', 'Tambah Data user Berhasil');
        return redirect()->to('/user');
    }
 
    function edit($id)
    {
        $datauser = $this->user->find($id);
        if (empty($datauser)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data User Tidak ditemukan !');
        }
        $data['user'] = $datauser;
        return view('user/edit', $data);
    }
 
    public function update($id)
    {
        if (!$this->validate([
            'email' => [
                'rules' => 'required|valid_email',
                'errors' => [
                    'required' => '{field} Harus diisi',
                    'valid_email' => 'Email Harus Valid'
                ]
            ],
            'password' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'role' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
 
        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back();
        }
 
        $this->user->update($id, [
            'email' => $this->request->getVar('email'),
            'password' => $this->request->getVar('password'),
            'role' => $this->request->getVar('role'),
            
        ]);
        session()->setFlashdata('message', 'Update Data User Berhasil');
        return redirect()->to('/user');
    }
 
    function delete($id)
    {
        $datauser = $this->user->find($id);
        if (empty($datauser)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data User Tidak ditemukan !');
        }
        $this->user->delete($id);
        session()->setFlashdata('message', 'Delete Data user Berhasil');
        return redirect()->to('/user');
    }
}
