<?php

namespace App\Models;

use CodeIgniter\Model;
use App\Models\User;
use App\Models\Pekerjaan;
use App\Models\Pendidikan;
use App\Models\Pelatihan;

class Biodata extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'biodata';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = false;
    protected $allowedFields    = ['nama','tempat','tanggal_lahir','posisi'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    /*public function getBiodata($id = false)
    {
        if($id === false){
            return $this->table('biodata')
                        ->join('user', 'user.id = biodata.id_user')
                        ->get()
                        ->getResultArray();
        } else {
            return $this->table('biodata')
                        ->join('user', 'user.id = biodata.id_user')
                        ->where('biodata.id', $id)
                        ->get()
                        ->getRowArray();
        }
        
        
    }*/

    public function getPendidikan($id = false)
    {
        if($id === false){
            return $this->table('biodata')
                        ->join('user', 'user.id = biodata.id_user')
                        ->join('pendidikan', 'pendidikan.id = biodata.id_pendidikan')
                        //->join()
                        ->get()
                        ->getResultArray();
        } else {
            return $this->table('biodata')
                        ->join('user', 'user.id = biodata.id_user')
                        ->join('pendidikan', 'pendidikan.id = biodata.id_pendidikan')
                        ->where('biodata.id', $id)
                        ->get()
                        ->getRowArray();
        }   
    }
   
}
